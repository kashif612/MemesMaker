import React from "react"
import Header from "./Header"
import MemeGenerator from "./MemeGenerator"
import 'C:/Users/mrina/myfirstreact/src/memestyle.css'

function App() {
    return (
        <div>
            <Header />
            <MemeGenerator />
        </div>
    )
}

export default App